// this file is going to initialize the MCPWM1 module
//so that



#define PWMPERIOD 3000

void IntMCPWM();

